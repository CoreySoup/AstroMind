//
//  StatsController.h
//  AstroMind
//
//  Created by collins on 4/30/17.
//  Copyright © 2017 akshay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CircularChart.h>
#import "MCPieChartView.h"

@interface StatsController : UIViewController<MCPieChartViewDelegate, MCPieChartViewDataSource>

@property (weak, nonatomic) IBOutlet MCPieChartView *pieChartView;

@end
