//
//  StatsController.m
//  AstroMind
//
//  Created by collins on 4/30/17.
//  Copyright © 2017 akshay. All rights reserved.
//

#import "StatsController.h"
//#import <PieChart.h>
#import "MCPieChartView.h"

@interface StatsController (){
    
    int header_height;
    
}

@end

@implementation StatsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    CGRect frame = CGRectMake(0, 0, 80, 80);
//    MCPieChartView *pieChartView = [[MCPieChartView alloc] initWithFrame:frame];
//    [self.view addSubview:pieChartView];
    
    self.pieChartView.dataSource = self;
    self.pieChartView.delegate = self;
    self.pieChartView.animationDuration = 0.5;
    self.pieChartView.sliceColor = [MCUtil flatWetAsphaltColor];
    self.pieChartView.borderColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.selectedSliceColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.textColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.selectedTextColor = [MCUtil flatWetAsphaltColor];
    self.pieChartView.borderPercentage = 0.01;

    
    
}

-(CGFloat)pieChartView:(MCPieChartView *)pieChartView valueForSliceAtIndex:(NSInteger)index{
    
    return 20;
    
}

-(NSInteger)numberOfSlicesInPieChartView:(MCPieChartView *)pieChartView{
    
    return 6;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
