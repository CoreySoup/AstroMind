//
//  ViewController.h
//  AstroMind
//
//  Created by collins on 4/30/17.
//  Copyright © 2017 akshay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *loginButton;

- (IBAction)loginButton:(id)sender;



@end

