//
//  VideoController.h
//  AstroMind
//
//  Created by collins on 4/30/17.
//  Copyright © 2017 akshay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

- (IBAction)Logout:(id)sender;

- (IBAction)videoButtyon:(id)sender;

@end
